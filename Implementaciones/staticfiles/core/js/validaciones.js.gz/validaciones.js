(
  function ctrlSubmit(formulario){
    formulario.disabled=true;
    formulario.form.submit();
  }

);
